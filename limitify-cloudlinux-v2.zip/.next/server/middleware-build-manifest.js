globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/ScdHbR87Kc6lTcmhHLYoz/_buildManifest.js",
    "static/ScdHbR87Kc6lTcmhHLYoz/_ssgManifest.js",
    "static/ScdHbR87Kc6lTcmhHLYoz/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3s6nzrbk-8mnv.js",
    "static/chunks/0fy4h0ngk1igg.js",
    "static/chunks/3g4px251sg85e.js",
    "static/chunks/0jh52hcy7u-xt.js",
    "static/chunks/3450qyhportkm.js",
    "static/chunks/turbopack-3cexo5lww-f_r.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
